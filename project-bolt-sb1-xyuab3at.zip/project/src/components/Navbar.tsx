import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Menu, LogOut, User, BookOpen, Settings } from 'lucide-react';

function Navbar() {
  const { user, logout } = useAuth();

  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="text-xl font-bold text-blue-600 flex items-center">
            <BookOpen className="w-6 h-6 mr-2" />
            Resource Booking
          </Link>

          <div className="flex items-center space-x-4">
            {user ? (
              <>
                <Link to="/my-bookings" className="text-gray-600 hover:text-blue-600 flex items-center">
                  <Menu className="w-5 h-5 mr-1" />
                  My Bookings
                </Link>
                {user.role === 'admin' && (
                  <Link to="/admin" className="text-gray-600 hover:text-blue-600 flex items-center">
                    <Settings className="w-5 h-5 mr-1" />
                    Admin
                  </Link>
                )}
                <button
                  onClick={logout}
                  className="text-gray-600 hover:text-blue-600 flex items-center"
                >
                  <LogOut className="w-5 h-5 mr-1" />
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="text-gray-600 hover:text-blue-600 flex items-center"
                >
                  <User className="w-5 h-5 mr-1" />
                  Login
                </Link>
                <Link
                  to="/register"
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
                >
                  Register
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;