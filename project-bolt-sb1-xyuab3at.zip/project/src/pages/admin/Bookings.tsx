import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { format } from 'date-fns';
import { toast } from 'react-hot-toast';
import { Calendar, Clock, User, CheckCircle, XCircle } from 'lucide-react';

interface Booking {
  _id: string;
  user: {
    email: string;
  };
  equipment: {
    name: string;
    image: string;
  };
  scale: {
    name: string;
    duration: number;
  };
  startTime: string;
  endTime: string;
  status: 'pending' | 'confirmed' | 'cancelled';
}

function AdminBookings() {
  const [bookings, setBookings] = useState<Booking[]>([]);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const { data } = await axios.get('/api/bookings');
      setBookings(data);
    } catch (error) {
      toast.error('Failed to fetch bookings');
    }
  };

  const updateStatus = async (id: string, status: 'confirmed' | 'cancelled') => {
    try {
      await axios.put(`/api/bookings/${id}/status`, { status });
      toast.success(`Booking ${status} successfully`);
      fetchBookings();
    } catch (error) {
      toast.error('Failed to update booking status');
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Booking Management</h1>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {bookings.map((booking) => (
          <div key={booking._id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">{booking.equipment.name}</h2>
                <span className={`px-3 py-1 rounded-full text-sm ${
                  booking.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                  booking.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                  'bg-yellow-100 text-yellow-800'
                }`}>
                  {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                </span>
              </div>
              <div className="space-y-3">
                <div className="flex items-center text-gray-600">
                  <User className="w-5 h-5 mr-2" />
                  <span>{booking.user.email}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Calendar className="w-5 h-5 mr-2" />
                  <span>{format(new Date(booking.startTime), 'PPP')}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Clock className="w-5 h-5 mr-2" />
                  <span>
                    {format(new Date(booking.startTime), 'p')} - {format(new Date(booking.endTime), 'p')}
                  </span>
                </div>
                <div className="text-sm text-gray-600">
                  Scale: {booking.scale.name} ({booking.scale.duration} minutes)
                </div>
              </div>
              {booking.status === 'pending' && (
                <div className="mt-4 flex space-x-2">
                  <button
                    onClick={() => updateStatus(booking._id, 'confirmed')}
                    className="flex items-center px-3 py-1 bg-green-100 text-green-800 rounded-md hover:bg-green-200"
                  >
                    <CheckCircle className="w-4 h-4 mr-1" />
                    Confirm
                  </button>
                  <button
                    onClick={() => updateStatus(booking._id, 'cancelled')}
                    className="flex items-center px-3 py-1 bg-red-100 text-red-800 rounded-md hover:bg-red-200"
                  >
                    <XCircle className="w-4 h-4 mr-1" />
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
      {bookings.length === 0 && (
        <div className="text-center text-gray-500">
          No bookings found.
        </div>
      )}
    </div>
  );
}

export default AdminBookings;