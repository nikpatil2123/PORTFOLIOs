import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-hot-toast';
import { Plus, Edit, Trash2, Clock } from 'lucide-react';

interface Scale {
  _id: string;
  name: string;
  duration: number;
}

interface Equipment {
  _id: string;
  name: string;
  description: string;
  image: string;
  scales: Scale[];
  available: boolean;
}

function AdminEquipment() {
  const [equipment, setEquipment] = useState<Equipment[]>([]);

  useEffect(() => {
    fetchEquipment();
  }, []);

  const fetchEquipment = async () => {
    try {
      const { data } = await axios.get('/api/equipment');
      setEquipment(data);
    } catch (error) {
      toast.error('Failed to fetch equipment');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this equipment?')) {
      return;
    }

    try {
      await axios.delete(`/api/equipment/${id}`);
      toast.success('Equipment deleted successfully');
      fetchEquipment();
    } catch (error) {
      toast.error('Failed to delete equipment');
    }
  };

  const toggleAvailability = async (id: string, available: boolean) => {
    try {
      await axios.put(`/api/equipment/${id}`, { available: !available });
      toast.success('Equipment availability updated');
      fetchEquipment();
    } catch (error) {
      toast.error('Failed to update equipment');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Equipment Management</h1>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center">
          <Plus className="w-5 h-5 mr-2" />
          Add Equipment
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {equipment.map((item) => (
          <div key={item._id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={item.image}
              alt={item.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-xl font-semibold">{item.name}</h2>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => toggleAvailability(item._id, item.available)}
                    className={`px-3 py-1 rounded-full text-sm ${
                      item.available
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {item.available ? 'Available' : 'Unavailable'}
                  </button>
                  <button
                    className="text-blue-600 hover:text-blue-800"
                    title="Edit"
                  >
                    <Edit className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDelete(item._id)}
                    className="text-red-600 hover:text-red-800"
                    title="Delete"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <p className="text-gray-600 mb-4">{item.description}</p>
              <div className="space-y-2">
                <h3 className="font-medium">Scales:</h3>
                {item.scales.map((scale) => (
                  <div key={scale._id} className="flex items-center text-sm text-gray-600">
                    <Clock className="w-4 h-4 mr-2" />
                    <span>{scale.name}: {scale.duration} minutes</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default AdminEquipment;