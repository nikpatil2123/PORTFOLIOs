import mongoose from 'mongoose';

const scaleSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  duration: {
    type: Number, // Duration in minutes
    required: true,
  },
});

const equipmentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  image: {
    type: String,
    required: true,
  },
  scales: [scaleSchema],
  available: {
    type: Boolean,
    default: true,
  },
}, { timestamps: true });

export default mongoose.model('Equipment', equipmentSchema);