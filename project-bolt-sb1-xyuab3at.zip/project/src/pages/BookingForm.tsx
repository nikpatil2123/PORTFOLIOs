import React from 'react';
import { useForm } from 'react-hook-form';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import axios from 'axios';
import { Calendar } from 'lucide-react';

interface BookingForm {
  scaleId: string;
  startTime: string;
}

function BookingForm() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors } } = useForm<BookingForm>();

  const onSubmit = async (data: BookingForm) => {
    try {
      await axios.post('/api/bookings', {
        equipment: id,
        ...data
      });
      toast.success('Booking created successfully!');
      navigate('/my-bookings');
    } catch (error) {
      toast.error('Failed to create booking');
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="bg-white p-8 rounded-lg shadow-md">
        <div className="flex items-center justify-center mb-6">
          <Calendar className="w-8 h-8 text-blue-600 mr-2" />
          <h1 className="text-2xl font-bold">Book Equipment</h1>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label htmlFor="scaleId" className="block text-sm font-medium text-gray-700">
              Scale
            </label>
            <select
              id="scaleId"
              {...register('scaleId', { required: 'Please select a scale' })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="">Select a scale</option>
              {/* Scales will be populated from equipment data */}
            </select>
            {errors.scaleId && (
              <p className="mt-1 text-sm text-red-600">{errors.scaleId.message}</p>
            )}
          </div>
          <div>
            <label htmlFor="startTime" className="block text-sm font-medium text-gray-700">
              Start Time
            </label>
            <input
              type="datetime-local"
              id="startTime"
              {...register('startTime', { required: 'Please select a start time' })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
            {errors.startTime && (
              <p className="mt-1 text-sm text-red-600">{errors.startTime.message}</p>
            )}
          </div>
          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Create Booking
          </button>
        </form>
      </div>
    </div>
  );
}

export default BookingForm;