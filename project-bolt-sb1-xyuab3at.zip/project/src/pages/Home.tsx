import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { Clock } from 'lucide-react';

interface Scale {
  _id: string;
  name: string;
  duration: number;
}

interface Equipment {
  _id: string;
  name: string;
  description: string;
  image: string;
  scales: Scale[];
}

function Home() {
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchEquipment = async () => {
      try {
        const { data } = await axios.get('/api/equipment');
        setEquipment(Array.isArray(data) ? data : []);
      } catch (err) {
        setError('Failed to load equipment');
      } finally {
        setLoading(false);
      }
    };
    fetchEquipment();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="text-gray-600">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="text-red-600">{error}</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Available Equipment</h1>
      {equipment.length === 0 ? (
        <div className="text-center text-gray-600">
          No equipment available at the moment.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {equipment.map((item) => (
            <div key={item._id} className="bg-white rounded-lg shadow-md overflow-hidden">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h2 className="text-xl font-semibold mb-2">{item.name}</h2>
                <p className="text-gray-600 mb-4">{item.description}</p>
                <div className="space-y-2">
                  <h3 className="font-medium">Available Scales:</h3>
                  {item.scales.map((scale) => (
                    <div key={scale._id} className="flex items-center text-sm text-gray-600">
                      <Clock className="w-4 h-4 mr-2" />
                      <span>{scale.name}: {scale.duration} minutes</span>
                    </div>
                  ))}
                </div>
                <Link
                  to={`/equipment/${item._id}`}
                  className="mt-4 inline-block bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
                >
                  Book Now
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Home;